#include <iostream>
using namespace std;
int main() {
    int x = 10;
    cout << "Memory location: "<<&x<<endl;
    int* ptr = (int*) &x;
    cout<< "The value at this memory location is equal to "<< *ptr<<endl;

    return 0;
}


